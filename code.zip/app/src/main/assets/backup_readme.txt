Hi!

Yes, the backup is just a simple zip file, and the files themselves are plain text.
You can edit it if you want, and the app will try to load it anyway, but be careful because it may become unusable.
If it does, you'll need to delete the corrupted data (for example by loading the original backup).

For more information, and to know how it is created/loaded, you can just check the source code:
https://github.com/TrianguloY/URLCheck/blob/master/app/src/main/java/com/ekodomo/urlchecker/activities/BackupActivity.java