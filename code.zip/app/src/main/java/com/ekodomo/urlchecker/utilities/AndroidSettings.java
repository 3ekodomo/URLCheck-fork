package com.ekodomo.urlchecker.utilities;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.util.Log;

import com.ekodomo.urlchecker.R;
import com.ekodomo.urlchecker.fragments.ResultCodeInjector;
import com.ekodomo.urlchecker.utilities.generics.GenericPref.BoolPref;
import com.ekodomo.urlchecker.utilities.generics.GenericPref.EnumerationPref;
import com.ekodomo.urlchecker.utilities.generics.GenericPref.IntPref;
import com.ekodomo.urlchecker.utilities.generics.GenericPref.StringPref;

public interface AndroidSettings {

    /* ------------------- day/light theme ------------------- */

    /** The theme setting */
    enum Theme implements Enums.IdEnum, Enums.StringEnum {
        DEFAULT(0, R.string.deviceDefault),
        DARK(1, R.string.spin_darkTheme),
        LIGHT(2, R.string.spin_lightTheme),
        AMOLED(3, R.string.spin_amoledTheme),
        ;

        private final int id;
        private final int string;

        Theme(int id, int string) {
            this.id = id;
            this.string = string;
        }

        @Override
        public int getId() {
            return id;
        }

        @Override
        public int getStringResource() {
            return string;
        }
    }

    /** The theme pref */
    static EnumerationPref<Theme> THEME_PREF(Context cntx) {
        return new EnumerationPref<>("dayNight", Theme.DEFAULT, Theme.class, cntx);
    }

    /** Sets the theme (light/dark mode) to an activity */
    static void setTheme(Context activity, boolean dialog) {
        activity.setTheme(switch (THEME_PREF(activity).get()) {
            case DEFAULT -> {
                if (!dialog && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // is dayNight different to manually choosing dark or light? no idea, but it exists so...
                    yield R.style.ActivityThemeDayNight;
                }

                // explicit light mode (uiMode=NIGHT_NO)
                // dark mode or device default
                if ((activity.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_NO)
                    yield dialog ? R.style.DialogThemeLight : R.style.ActivityThemeLight;
                else
                    yield dialog ? R.style.DialogThemeDark : R.style.ActivityThemeDark;
            }
            case DARK -> dialog ? R.style.DialogThemeDark : R.style.ActivityThemeDark;
            case LIGHT -> dialog ? R.style.DialogThemeLight : R.style.ActivityThemeLight;
            case AMOLED -> dialog ? R.style.DialogThemeAmoled : R.style.ActivityThemeAmoled;
        });
    }

    /* ------------------- ui edges ------------------- */

    enum Edges implements Enums.IdEnum, Enums.StringEnum {
        ROUNDED(0, R.string.spin_edges_rounded),
        SHARP(1, R.string.spin_edges_sharp),
        DEFAULT(2, R.string.spin_edges_default),
        ;

        private final int id;
        private final int string;

        Edges(int id, int string) {
            this.id = id;
            this.string = string;
        }

        @Override
        public int getId() {
            return id;
        }

        @Override
        public int getStringResource() {
            return string;
        }
    }

    static EnumerationPref<Edges> EDGES_PREF(Context cntx) {
        return new EnumerationPref<>("edges", Edges.DEFAULT, Edges.class, cntx);
    }

    static IntPref ROUNDED_AMOUNT_PREF(Context cntx) {
        return new IntPref("roundedAmount", 20, cntx);
    }

    /** Overall dialog/window edge style. Kept separate from element edges. */
    enum OverallEdges implements Enums.IdEnum, Enums.StringEnum {
        DEFAULT(0, R.string.spin_overall_edges_default),
        SHARP(1, R.string.spin_overall_edges_sharp),
        ROUNDED(2, R.string.spin_overall_edges_rounded),
        ;

        private final int id;
        private final int string;

        OverallEdges(int id, int string) {
            this.id = id;
            this.string = string;
        }

        @Override
        public int getId() {
            return id;
        }

        @Override
        public int getStringResource() {
            return string;
        }
    }

    static EnumerationPref<OverallEdges> OVERALL_EDGES_PREF(Context cntx) {
        return new EnumerationPref<>("overallEdges", OverallEdges.DEFAULT, OverallEdges.class, cntx);
    }

    static BoolPref SHOW_ELEMENT_BORDER_PREF(Context cntx) {
        return new BoolPref("showElementBorder", false, cntx);
    }

    static BoolPref SHOW_OVERALL_INTERFACE_BORDER_PREF(Context cntx) {
        return new BoolPref("showOverallInterfaceBorder", false, cntx);
    }

    static String getDefaultOverallBorderColor(Context cntx) {
        return getDefaultBorderColor(cntx);
    }

    /**
     * Returns the storage key for a colour override belonging to the currently
     * effective theme. DEFAULT is resolved to LIGHT/DARK first, so each actual
     * appearance keeps its own colour instead of sharing one value.
     */
    static String themeColorKey(Context cntx, String baseName) {
        return baseName + "_" + getResolvedTheme(cntx).name().toLowerCase();
    }

    static StringPref OVERALL_BORDER_COLOR_PREF(Context cntx) {
        return new StringPref(
                themeColorKey(cntx, "overall_border_color"),
                getDefaultOverallBorderColor(cntx),
                cntx
        );
    }

    static IntPref OVERALL_BORDER_WIDTH_PREF(Context cntx) {
        return new IntPref("overall_border_width", 2, cntx);
    }

    /** Corner radius used only when the overall interface edge is ROUNDED. */
    static IntPref OVERALL_ROUNDED_AMOUNT_PREF(Context cntx) {
        return new IntPref("overall_rounded_amount", 28, cntx);
    }

    static Theme getResolvedTheme(Context cntx) {
        Theme theme = THEME_PREF(cntx).get();
        if (theme == Theme.DEFAULT) {
            boolean isDark = (cntx.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
            return isDark ? Theme.DARK : Theme.LIGHT;
        }
        return theme;
    }

    static String getDefaultElementColor(Context cntx) {
        Theme theme = getResolvedTheme(cntx);
        if (theme == Theme.AMOLED) return "#000000";
        if (theme == Theme.DARK) return "#1E1F24";
        return "#FFFFFF";
    }

    static String getDefaultBorderColor(Context cntx) {
        Theme theme = getResolvedTheme(cntx);
        if (theme == Theme.AMOLED) return "#333333";
        if (theme == Theme.DARK) return "#555555";
        return "#CCCCCC";
    }

    /**
     * Element color is an override for the current effective theme. If there is
     * no override, get() returns the current theme's native default.
     */
    static StringPref ELEMENT_COLOR_PREF(Context cntx) {
        return new StringPref(
                themeColorKey(cntx, "element_color"),
                getDefaultElementColor(cntx),
                cntx
        );
    }

    /** Border color is also an override scoped to the current effective theme. */
    static StringPref BORDER_COLOR_PREF(Context cntx) {
        return new StringPref(
                themeColorKey(cntx, "border_color"),
                getDefaultBorderColor(cntx),
                cntx
        );
    }

    /* ------------------- reloading ------------------- */

    String RELOAD_EXTRA = "reloaded";
    int RELOAD_RESULT_CODE = Activity.RESULT_FIRST_USER;

    /** destroys and recreates the activity (to apply changes) and marks it */
    static void reload(Activity cntx) {
        Log.d("SETTINGS", "reloading");
        cntx.getIntent().putExtra(RELOAD_EXTRA, true); // keep data
        cntx.recreate();
    }

    /** Returns true if the activity was reloaded (with {@link AndroidSettings#reload}) and clears the flag */
    static boolean wasReloaded(Activity cntx) {
        var intent = cntx.getIntent();
        var reloaded = intent.getBooleanExtra(RELOAD_EXTRA, false);
        intent.removeExtra(RELOAD_EXTRA);
        return reloaded;
    }

    /** Registers an activity result to reload if the launched activity is marked as reloading using{@link AndroidSettings#markForReloading(Activity)} */
    static int registerForReloading(ResultCodeInjector resultCodeInjector, Activity cntx) {
        return resultCodeInjector.registerActivityResult((resultCode, data) -> {
            if (resultCode == RELOAD_RESULT_CODE) {
                AndroidSettings.reload(cntx);
            }
        });
    }

    /** Makes the activity that launched this one to reload, if registered with {@link AndroidSettings#registerForReloading(ResultCodeInjector, Activity)} */
    static void markForReloading(Activity cntx) {
        cntx.setResult(RELOAD_RESULT_CODE);
    }

}
